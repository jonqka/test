document.getElementById("slider").addEventListener("change", function() {
    console.log("Slider changed");
});
